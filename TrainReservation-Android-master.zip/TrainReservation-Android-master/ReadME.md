# TrainReservation-Android

## 설명 및 서버
https://github.com/kktyal/TrainReservation-Server
