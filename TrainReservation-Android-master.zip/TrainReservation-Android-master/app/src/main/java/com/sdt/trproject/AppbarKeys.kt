package com.sdt.trproject

object AppbarKeys {
    const val LOG_IN = "로그인"
    const val LOG_OUT = "로그아웃"
    const val LOG_OUT_STATUS = "로그인 하세요."
    const val LOG_IN_STATUS = "님 \n 안녕하세요 \n 발권내역 : "

}