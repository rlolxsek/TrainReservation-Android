package com.sdt.trproject

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MyApplication: Application() {
    // Application
    // Multi Dex
    // Memory, App 관한 것들...
}