package com.sdt.trproject.appbar_title

object AppbarTitle {
    const val MAIN_TITLE = "SRT"
}